/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.utils;

/**
 *
 * @author user
 */
public interface Operation {
    public static final int OPERATION_PRIJAVA   = 1;
    public static final int OPERATION_SACUVAJ_KLIJENTA = 2;
    public static final int VRATI_KLIJENTE = 3;
    public static int OPERATION_OBRISI_KLIJENTA = 4;
    public static int OPERATION_SACUVAJ_REZIM = 5;
    public static int VRATI_REZIME = 6;
    public static int OPERATION_OBRISI_STAVKU = 7;
    public static int OPERATION_SACUVAJ_STAVKU = 8;
    public static int OPERATION_IZMENI_STAVKU = 9;
    public static int VRATI_VRSTE = 10;
    
}
